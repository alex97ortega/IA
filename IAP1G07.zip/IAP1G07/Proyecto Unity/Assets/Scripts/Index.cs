﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Index : MonoBehaviour {
    public uint index;
    public uint GetIndex() { return index; }
}
